-----------------------------------------------------
Flash frame rate readout
-----------------------------------------------------
by Richard Lord
Copyright Big Room Ventures Limited 2003.
http://www.bigroom.co.uk/

Use this movie wherever you like, but
leave this copyright notice in.
-----------------------------------------------------
Simply load the swf movie into a movieclip or level to
see a readout of the frame rate.

e.g.
  loadMovieNum("timer.swf", 10);
 
The frame rate will then appear in black text in the top
left corner of the movie.

Choose a level above any already in use to prevent
obscuring the frame rate with other content.
-----------------------------------------------------
