As3-Signals is by Josh McDonald. It is available at http://github.com/sophistifunk/SmartyPants-IOC
and is released under the New BSD License - http://www.opensource.org/licenses/bsd-license.php