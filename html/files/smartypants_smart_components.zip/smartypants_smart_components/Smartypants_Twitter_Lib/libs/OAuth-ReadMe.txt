This OAuth library combines work by

Sönke Rohde (http://github.com/srohde/OAuth) released under the
Apache2.0 license - http://www.apache.org/licenses/LICENSE-2.0

Shannon Hicks (http://code.google.com/p/oauth-as3/) released under
the Apache2.0 license - http://www.apache.org/licenses/LICENSE-2.0

Henri Torgemane (http://code.google.com/p/as3crypto/) released under the
New BSD License - http://as3crypto.googlecode.com/svn/trunk/as3crypto/LICENSE.txt